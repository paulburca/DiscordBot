package com.pein.bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscordBotRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
