package com.pein.Rest;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RESTController {

}
