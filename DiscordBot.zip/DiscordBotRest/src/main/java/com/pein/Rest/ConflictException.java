package com.pein.Rest;

public class ConflictException extends RuntimeException{
    public ConflictException(String msg){super(msg);}
}
