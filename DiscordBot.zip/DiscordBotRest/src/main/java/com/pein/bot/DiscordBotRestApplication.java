package com.pein.bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class DiscordBotRestApplication {

    public static void main(String[] args) {

//        SpringApplication.run(DiscordBotRestApplication.class, args);
    }

}
